import React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { useNavigate } from "react-router-dom";

interface Pizza {
  id: string;
  name: string;
  description: string;
  price: string;
  image: string;
}

const pizzas: Pizza[] = [
  {
    id: "lotsa-meat",
    name: "Lotsa Meat",
    description: "A carnivore\'s dream! Packed with pepperoni, Italian sausage, beef, and bacon.",
    price: "$11.99",
    image: "https://images.unsplash.com/photo-1593560708920-61dd98c46a4e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1920&q=80"
  },
  {
    id: "veggie-delight",
    name: "Veggie Delight",
    description: "Loaded with fresh bell peppers, mushrooms, onions, black olives, and banana peppers.",
    price: "$11.99",
    image: "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1920&q=80"
  },
  {
    id: "loaded",
    name: "Loaded",
    description: "The best of both worlds! Pepperoni, sausage, beef, bacon, and all the veggies.",
    price: "$13.99",
    image: "https://images.unsplash.com/photo-1604382354936-07c5d9983bd3?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1920&q=80"
  }
];

export default function App() {
  const navigate = useNavigate();

  const handleOrderNow = (pizzaId: string) => {
    navigate(`/BuildPage`);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <header
        className="bg-cover bg-center py-24 md:py-32"
        style={{ backgroundImage: "url('\https://images.unsplash.com/photo-1513104890138-7c749659a591?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1920&q=80')"}}
      >
        <div className="container mx-auto px-4 text-center text-white">
          <h1 className="text-4xl md:text-6xl font-bold mb-4" style={{ textShadow: "2px 2px 4px rgba(0,0,0,0.7)" }}>
            Hunt Brothers Pizza
          </h1>
          <p className="text-lg md:text-2xl mb-8" style={{ textShadow: "1px 1px 2px rgba(0,0,0,0.7)" }}>
            Made Fresh to Order, Just for You!
          </p>
          <Button
            size="lg"
            className="bg-red-600 hover:bg-red-700 text-white font-semibold py-3 px-8 rounded-lg text-lg shadow-lg transform transition-transform hover:scale-105"
            onClick={() => navigate("/BuildPage")}
          >
            Order Now
          </Button>
        </div>
      </header>

      {/* Call to Action Section */}
      <section className="py-12 bg-yellow-500 text-center">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl md:text-3xl font-semibold text-gray-800 mb-4">
            Need help placing an order?
          </h2>
          <p className="text-xl md:text-2xl text-gray-700">
            Call us now at{" "}
            <a
              href="tel:3614030083"
              className="text-red-600 hover:underline font-bold"
            >
              (361) 403-0083
            </a>
            !
          </p>
        </div>
      </section>

      <main className="container mx-auto px-4 py-12 md:py-16">
        <h2 className="text-3xl md:text-4xl font-bold text-center text-gray-800 mb-12">
          Our Signature Pizzas
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {pizzas.map((pizza) => (
            <Card key={pizza.id} className="rounded-xl shadow-lg overflow-hidden transform transition-transform hover:scale-105 hover:shadow-xl">
              <CardHeader className="p-0">
                <img src={pizza.image} alt={pizza.name} className="w-full h-48 object-cover" />
              </CardHeader>
              <CardContent className="p-6">
                <CardTitle className="text-2xl font-bold text-gray-800 mb-2">{pizza.name} - {pizza.price}</CardTitle>
                <CardDescription className="text-gray-600 mb-4 h-20">
                  {pizza.description}
                </CardDescription>
              </CardContent>
              <CardFooter className="p-6 bg-gray-50">
                <Button
                  className="w-full bg-yellow-500 hover:bg-yellow-600 text-gray-800 font-semibold py-3 rounded-lg shadow-md"
                  onClick={() => handleOrderNow(pizza.id)}
                >
                  Order This Pizza
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </main>

      <footer className="bg-gray-800 text-gray-300 py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
            {/* Column 1: Contact Info */}
            <div className="mb-8 md:mb-0">
              <h3 className="text-xl font-semibold text-yellow-500 mb-4">
                Lemur Express 11
              </h3>
              <p className="mb-2 flex items-center">
                <span className="mr-2 text-xl">📍</span> {/* Location Icon */}
                2100 1st Street, Palacios, TX 77465
              </p>
              <p className="mb-2 flex items-center">
                <span className="mr-2 text-xl">📞</span> {/* Phone Icon */}
                <a href="tel:3614030083" className="hover:text-yellow-500">(361) 403-0083</a>
              </p>
            </div>

            {/* Column 2: Store Hours & Copyright */}
            <div>
              <h3 className="text-xl font-semibold text-yellow-500 mb-4">
                Store Hours
              </h3>
              <p className="mb-2 flex items-center">
                <span className="mr-2 text-xl">🕒</span> {/* Clock Icon */}
                Open Daily – 9:00 AM to 12:00 AM
              </p>
              <p className="mt-8 text-sm text-gray-500">
                &copy; {new Date().getFullYear()} PizzaFlow. All rights reserved.
              </p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
