import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

// Define types for pizza customization
interface PizzaOption {
  id: string;
  name: string;
  price?: number;
}

interface ToppingSide {
  toppingId: string;
  isExtra: boolean;
}

interface CartPizza {
  id: string;
  crust: string;
  isHalfAndHalf: boolean;
  leftToppings: ToppingSide[];
  rightToppings: ToppingSide[];
  regularToppings: ToppingSide[]; // For non-half-and-half
  hasDoubleCheese: boolean;
  price: number;
}

const crustOptions = [
  { id: "original", name: "Original Crust" },
  { id: "thin", name: "Thin Crust" },
];

const toppingsOptions = [
  { id: "pepperoni", name: "Pepperoni", type: "meat" },
  { id: "italian-sausage", name: "Italian Sausage", type: "meat" },
  { id: "beef", name: "Beef", type: "meat" },
  { id: "bacon", name: "Bacon", type: "meat" },
  { id: "bell-peppers", name: "Bell Peppers", type: "veggie" },
  { id: "mushrooms", name: "Mushrooms", type: "veggie" },
  { id: "onions", name: "Onions", type: "veggie" },
  { id: "black-olives", name: "Black Olives", type: "veggie" },
  { id: "banana-peppers", name: "Banana Peppers", type: "veggie" },
  { id: "jalapenos", name: "Jalapeños", type: "veggie" },
];

export default function BuildPage() {
  // Pizza customization states
  const [selectedCrust, setSelectedCrust] = useState<string>("original");
  const [isHalfAndHalf, setIsHalfAndHalf] = useState<boolean>(false);
  const [leftToppings, setLeftToppings] = useState<ToppingSide[]>([]);
  const [rightToppings, setRightToppings] = useState<ToppingSide[]>([]);
  const [regularToppings, setRegularToppings] = useState<ToppingSide[]>([]);
  const [hasDoubleCheese, setHasDoubleCheese] = useState<boolean>(false);
  
  // Cart state
  const [cartPizzas, setCartPizzas] = useState<CartPizza[]>([]);
  
  // Price calculation
  const basePizzaPrice = 11.99;
  const doubleCheesePrice = 2.19;
  const extraMeatPrice = 1.50;
  const extraVeggiePrice = 1.00;
  const taxRate = 0.0825; // 8.25%
  
  // Calculate extra toppings cost
  const calculateExtraCost = (toppings: ToppingSide[]) => {
    return toppings.reduce((cost, topping) => {
      if (!topping.isExtra) return cost;
      const toppingOption = toppingsOptions.find(t => t.id === topping.toppingId);
      return cost + (toppingOption?.type === "meat" ? extraMeatPrice : extraVeggiePrice);
    }, 0);
  };
  
  const extraCost = isHalfAndHalf 
    ? calculateExtraCost(leftToppings) + calculateExtraCost(rightToppings)
    : calculateExtraCost(regularToppings);
    
  const subtotal = basePizzaPrice + (hasDoubleCheese ? doubleCheesePrice : 0) + extraCost;
  const tax = subtotal * taxRate;
  const total = subtotal + tax;
  
  // Handle topping selection
  const handleToppingToggle = (toppingId: string, side?: 'left' | 'right') => {
    const targetToppings = isHalfAndHalf 
      ? (side === 'left' ? leftToppings : rightToppings)
      : regularToppings;
    const setTargetToppings = isHalfAndHalf 
      ? (side === 'left' ? setLeftToppings : setRightToppings)
      : setRegularToppings;
    
    // Count total toppings across all sides
    const totalToppings = isHalfAndHalf 
      ? leftToppings.length + rightToppings.length
      : regularToppings.length;
    
    const existingIndex = targetToppings.findIndex(t => t.toppingId === toppingId);
    
    if (existingIndex >= 0) {
      // Remove topping
      setTargetToppings(prev => prev.filter((_, index) => index !== existingIndex));
    } else if (totalToppings < 10) {
      // Add topping if under limit
      setTargetToppings(prev => [...prev, { toppingId, isExtra: false }]);
    }
  };
  
  // Handle extra topping toggle
  const handleExtraToggle = (toppingId: string, side?: 'left' | 'right') => {
    const targetToppings = isHalfAndHalf 
      ? (side === 'left' ? leftToppings : rightToppings)
      : regularToppings;
    const setTargetToppings = isHalfAndHalf 
      ? (side === 'left' ? setLeftToppings : setRightToppings)
      : setRegularToppings;
    
    setTargetToppings(prev => 
      prev.map(topping => 
        topping.toppingId === toppingId 
          ? { ...topping, isExtra: !topping.isExtra }
          : topping
      )
    );
  };
  
  // Check if topping is selected
  const isToppingSelected = (toppingId: string, side?: 'left' | 'right') => {
    const targetToppings = isHalfAndHalf 
      ? (side === 'left' ? leftToppings : rightToppings)
      : regularToppings;
    return targetToppings.some(t => t.toppingId === toppingId);
  };
  
  // Check if topping is extra
  const isToppingExtra = (toppingId: string, side?: 'left' | 'right') => {
    const targetToppings = isHalfAndHalf 
      ? (side === 'left' ? leftToppings : rightToppings)
      : regularToppings;
    return targetToppings.find(t => t.toppingId === toppingId)?.isExtra || false;
  };
  
  // Handle add to cart
  const handleAddToCart = () => {
    const newPizza: CartPizza = {
      id: Date.now().toString(),
      crust: selectedCrust,
      isHalfAndHalf,
      leftToppings: [...leftToppings],
      rightToppings: [...rightToppings],
      regularToppings: [...regularToppings],
      hasDoubleCheese,
      price: total
    };
    
    setCartPizzas(prev => [...prev, newPizza]);
    
    // Enhanced console logging
    console.log('🍕 PIZZA ADDED TO CART 🍕');
    console.log('================================');
    console.log('Pizza Configuration:');
    console.log(`  Crust: ${selectedCrust === 'original' ? 'Original' : 'Thin'}`);
    console.log(`  Style: ${isHalfAndHalf ? 'Half-and-Half' : 'Regular'}`);
    console.log(`  Double Cheese: ${hasDoubleCheese ? 'Yes (+$2.19)' : 'No'}`);
    
    if (isHalfAndHalf) {
      console.log('\nLeft Side Toppings:');
      leftToppings.forEach(topping => {
        const toppingOption = toppingsOptions.find(t => t.id === topping.toppingId);
        const extraCost = topping.isExtra ? (toppingOption?.type === 'meat' ? 1.50 : 1.00) : 0;
        console.log(`  - ${toppingOption?.name} (${toppingOption?.type})${topping.isExtra ? ` [EXTRA +$${extraCost.toFixed(2)}]` : ' [FREE]'}`);
      });
      
      console.log('\nRight Side Toppings:');
      rightToppings.forEach(topping => {
        const toppingOption = toppingsOptions.find(t => t.id === topping.toppingId);
        const extraCost = topping.isExtra ? (toppingOption?.type === 'meat' ? 1.50 : 1.00) : 0;
        console.log(`  - ${toppingOption?.name} (${toppingOption?.type})${topping.isExtra ? ` [EXTRA +$${extraCost.toFixed(2)}]` : ' [FREE]'}`);
      });
    } else {
      console.log('\nToppings:');
      regularToppings.forEach(topping => {
        const toppingOption = toppingsOptions.find(t => t.id === topping.toppingId);
        const extraCost = topping.isExtra ? (toppingOption?.type === 'meat' ? 1.50 : 1.00) : 0;
        console.log(`  - ${toppingOption?.name} (${toppingOption?.type})${topping.isExtra ? ` [EXTRA +$${extraCost.toFixed(2)}]` : ' [FREE]'}`);
      });
    }
    
    console.log('\nPrice Breakdown:');
    console.log(`  Base Pizza: $${basePizzaPrice.toFixed(2)}`);
    if (hasDoubleCheese) {
      console.log(`  Double Cheese: +$${doubleCheesePrice.toFixed(2)}`);
    }
    if (extraCost > 0) {
      console.log(`  Extra Toppings: +$${extraCost.toFixed(2)}`);
    }
    console.log(`  Subtotal: $${subtotal.toFixed(2)}`);
    console.log(`  Tax (8.25%): +$${tax.toFixed(2)}`);
    console.log(`  TOTAL: $${total.toFixed(2)}`);
    console.log('================================');
    console.log(`Total pizzas in cart: ${cartPizzas.length + 1}`);
    
    // Reset form
    setSelectedCrust("original");
    setLeftToppings([]);
    setRightToppings([]);
    setRegularToppings([]);
    setHasDoubleCheese(false);
    setIsHalfAndHalf(false);
  };
  
  // Handle remove from cart
  const handleRemoveFromCart = (pizzaId: string) => {
    setCartPizzas(prev => prev.filter(pizza => pizza.id !== pizzaId));
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8 md:py-12">
      <div className="container mx-auto px-4">
        <header className="mb-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-red-600">
            Build Your Own Pizza
          </h1>
          <p className="text-lg text-gray-700 mt-2">
            Craft your perfect pizza from scratch!
          </p>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column: Pizza Customization Options */}
          <div className="lg:col-span-2 space-y-8">
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-2xl text-gray-800">Crust</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4">Select your crust type.</p>
                <RadioGroup value={selectedCrust} onValueChange={setSelectedCrust}>
                  {crustOptions.map((crust) => (
                    <div key={crust.id} className="flex items-center space-x-2 p-3 border rounded-lg hover:bg-gray-50 transition-colors">
                      <RadioGroupItem value={crust.id} id={crust.id} />
                      <Label htmlFor={crust.id} className="flex-1 cursor-pointer font-medium">
                        {crust.name}
                      </Label>
                    </div>
                  ))}
                </RadioGroup>
              </CardContent>
            </Card>

            {/* Pizza Style Toggle */}
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-lg font-semibold text-gray-800">Pizza Style</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50 transition-colors">
                  <div>
                    <Label htmlFor="half-and-half" className="font-medium cursor-pointer">
                      Half-and-Half Pizza
                    </Label>
                    <p className="text-sm text-gray-600">Different toppings on each side</p>
                  </div>
                  <Switch
                    id="half-and-half"
                    checked={isHalfAndHalf}
                    onCheckedChange={(checked) => {
                      setIsHalfAndHalf(checked);
                      // Reset toppings when switching modes
                      setLeftToppings([]);
                      setRightToppings([]);
                      setRegularToppings([]);
                    }}
                  />
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-2xl text-gray-800">Add-Ons</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">Any extras?</p>
                <div className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50 transition-colors">
                  <div>
                    <Label htmlFor="double-cheese" className="font-medium cursor-pointer">
                      Double Cheese
                    </Label>
                    <p className="text-sm text-gray-600">+$2.19</p>
                  </div>
                  <Switch
                    id="double-cheese"
                    checked={hasDoubleCheese}
                    onCheckedChange={setHasDoubleCheese}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Toppings Section */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg font-semibold text-gray-800">Toppings</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4">
                  Choose up to 10 toppings total. {isHalfAndHalf ? "Split between both sides." : "All toppings are free, extras cost more."}
                </p>
                <p className="text-sm text-gray-500 mb-4">
                  Selected: {isHalfAndHalf ? leftToppings.length + rightToppings.length : regularToppings.length}/10
                </p>
                
                {isHalfAndHalf ? (
                  <Tabs defaultValue="left" className="w-full">
                    <TabsList className="grid w-full grid-cols-2">
                      <TabsTrigger value="left">Left Side ({leftToppings.length})</TabsTrigger>
                      <TabsTrigger value="right">Right Side ({rightToppings.length})</TabsTrigger>
                    </TabsList>
                    
                    <TabsContent value="left" className="mt-4">
                      <div className="grid grid-cols-1 gap-3">
                        {toppingsOptions.map((topping) => {
                          const isSelected = isToppingSelected(topping.id, 'left');
                          const isExtra = isToppingExtra(topping.id, 'left');
                          const totalToppings = leftToppings.length + rightToppings.length;
                          const isDisabled = !isSelected && totalToppings >= 10;
                          
                          return (
                            <div key={`left-${topping.id}`} className={`p-3 border rounded-lg transition-colors ${
                              isDisabled ? 'bg-gray-100 opacity-50' : 'hover:bg-gray-50'
                            }`}>
                              <div className="flex items-center justify-between">
                                <div className="flex items-center space-x-2">
                                  <Checkbox
                                    id={`left-${topping.id}`}
                                    checked={isSelected}
                                    disabled={isDisabled}
                                    onCheckedChange={() => handleToppingToggle(topping.id, 'left')}
                                  />
                                  <Label htmlFor={`left-${topping.id}`} className="font-medium cursor-pointer">
                                    {topping.name}
                                    <span className="text-xs text-gray-500 ml-1">({topping.type})</span>
                                  </Label>
                                </div>
                                {isSelected && (
                                  <div className="flex items-center space-x-2">
                                    <Label htmlFor={`left-extra-${topping.id}`} className="text-sm text-gray-600">
                                      Extra (+${topping.type === 'meat' ? '$1.50' : '$1.00'})
                                    </Label>
                                    <Checkbox
                                      id={`left-extra-${topping.id}`}
                                      checked={isExtra}
                                      onCheckedChange={() => handleExtraToggle(topping.id, 'left')}
                                    />
                                  </div>
                                )}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </TabsContent>
                    
                    <TabsContent value="right" className="mt-4">
                      <div className="grid grid-cols-1 gap-3">
                        {toppingsOptions.map((topping) => {
                          const isSelected = isToppingSelected(topping.id, 'right');
                          const isExtra = isToppingExtra(topping.id, 'right');
                          const totalToppings = leftToppings.length + rightToppings.length;
                          const isDisabled = !isSelected && totalToppings >= 10;
                          
                          return (
                            <div key={`right-${topping.id}`} className={`p-3 border rounded-lg transition-colors ${
                              isDisabled ? 'bg-gray-100 opacity-50' : 'hover:bg-gray-50'
                            }`}>
                              <div className="flex items-center justify-between">
                                <div className="flex items-center space-x-2">
                                  <Checkbox
                                    id={`right-${topping.id}`}
                                    checked={isSelected}
                                    disabled={isDisabled}
                                    onCheckedChange={() => handleToppingToggle(topping.id, 'right')}
                                  />
                                  <Label htmlFor={`right-${topping.id}`} className="font-medium cursor-pointer">
                                    {topping.name}
                                    <span className="text-xs text-gray-500 ml-1">({topping.type})</span>
                                  </Label>
                                </div>
                                {isSelected && (
                                  <div className="flex items-center space-x-2">
                                    <Label htmlFor={`right-extra-${topping.id}`} className="text-sm text-gray-600">
                                      Extra (+${topping.type === 'meat' ? '$1.50' : '$1.00'})
                                    </Label>
                                    <Checkbox
                                      id={`right-extra-${topping.id}`}
                                      checked={isExtra}
                                      onCheckedChange={() => handleExtraToggle(topping.id, 'right')}
                                    />
                                  </div>
                                )}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </TabsContent>
                  </Tabs>
                ) : (
                  <div className="grid grid-cols-1 gap-3">
                    {toppingsOptions.map((topping) => {
                      const isSelected = isToppingSelected(topping.id);
                      const isExtra = isToppingExtra(topping.id);
                      const isDisabled = !isSelected && regularToppings.length >= 10;
                      
                      return (
                        <div key={topping.id} className={`p-3 border rounded-lg transition-colors ${
                          isDisabled ? 'bg-gray-100 opacity-50' : 'hover:bg-gray-50'
                        }`}>
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-2">
                              <Checkbox
                                id={topping.id}
                                checked={isSelected}
                                disabled={isDisabled}
                                onCheckedChange={() => handleToppingToggle(topping.id)}
                              />
                              <Label htmlFor={topping.id} className="font-medium cursor-pointer">
                                {topping.name}
                                <span className="text-xs text-gray-500 ml-1">({topping.type})</span>
                              </Label>
                            </div>
                            {isSelected && (
                              <div className="flex items-center space-x-2">
                                <Label htmlFor={`extra-${topping.id}`} className="text-sm text-gray-600">
                                  Extra (+${topping.type === 'meat' ? '$1.50' : '$1.00'})
                                </Label>
                                <Checkbox
                                  id={`extra-${topping.id}`}
                                  checked={isExtra}
                                  onCheckedChange={() => handleExtraToggle(topping.id)}
                                />
                              </div>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Right Column: Order Summary & Cart */}
          <div className="lg:col-span-1 space-y-6">
            <Card className="shadow-lg sticky top-8">
              <CardHeader>
                <CardTitle className="text-2xl text-yellow-600">Your Pizza</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h3 className="font-semibold text-gray-700">Subtotal:</h3>
                  <p className="text-lg font-bold text-gray-800">${subtotal.toFixed(2)}</p>
                </div>
                <div>
                  <h3 className="font-semibold text-gray-700">Tax (8.25%):</h3>
                  <p className="text-lg font-bold text-gray-800">${tax.toFixed(2)}</p>
                </div>
                <Separator />
                <div>
                  <h3 className="font-semibold text-gray-700 text-xl">Total:</h3>
                  <p className="text-2xl font-bold text-red-600">${total.toFixed(2)}</p>
                </div>
                <Button 
                  onClick={handleAddToCart}
                  className="w-full bg-red-600 hover:bg-red-700 text-white font-semibold py-3 rounded-lg text-lg shadow-md"
                >
                  Add to Cart - ${total.toFixed(2)}
                </Button>
                
                {/* Cart Summary */}
                {cartPizzas.length > 0 && (
                  <>
                    <Separator className="my-4" />
                    <div>
                      <h3 className="font-semibold text-gray-700 mb-3">Cart Summary</h3>
                      <div className="space-y-2 max-h-40 overflow-y-auto">
                        {cartPizzas.map((pizza, index) => (
                          <div key={pizza.id} className="flex justify-between items-center p-2 bg-gray-50 rounded">
                            <div className="flex-1">
                              <p className="text-sm font-medium">
                                Pizza #{index + 1} - {crustOptions.find(c => c.id === pizza.crust)?.name}
                              </p>
                              <p className="text-xs text-gray-600">
                                {pizza.toppings.length > 0 ? 
                                  pizza.toppings.map(id => 
                                    toppingsOptions.find(t => t.id === id)?.name
                                  ).join(", ") : "No toppings"}
                                {pizza.hasDoubleCheese && " + Double Cheese"}
                              </p>
                            </div>
                            <div className="flex items-center space-x-2">
                              <span className="text-sm font-medium">${pizza.price.toFixed(2)}</span>
                              <Button 
                                size="sm" 
                                variant="outline" 
                                onClick={() => handleRemoveFromCart(pizza.id)}
                                className="h-6 w-6 p-0 text-red-600 hover:text-red-700"
                              >
                                ×
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>

            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-2xl text-yellow-600">Cart</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-600 italic">Your cart is currently empty.</p>
                {/* Cart items will go here */}
                <Separator />
                <div className="flex justify-between items-center font-bold text-lg">
                  <span>Cart Total:</span>
                  <span>$0.00</span>
                </div>
                <Button
                  variant="outline"
                  className="w-full border-yellow-500 text-yellow-600 hover:bg-yellow-50 font-semibold py-3 rounded-lg text-lg shadow-md"
                  // onClick={() => navigate("/checkout")}
                >
                  Proceed to Checkout
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};


